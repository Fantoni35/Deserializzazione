package com.deserializzazione;

public class element {
    public String annoDiNascita;
    public String cognome;
    public String nome;
    
    public String getAnnoDiNascita() {
        return annoDiNascita;
    }
    public void setAnnoDiNascita(String annoDiNascita) {
        this.annoDiNascita = annoDiNascita;
    }
    public String getCognome() {
        return cognome;
    }
    public void setCognome(String cognome) {
        this.cognome = cognome;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }


    



    
}
